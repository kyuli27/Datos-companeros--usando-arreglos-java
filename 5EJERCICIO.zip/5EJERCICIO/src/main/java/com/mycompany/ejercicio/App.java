/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio;

/**
 *
 * @author 50497
 */
public class App {

    public static void main(String[] args) {
    String[][] datosCompaneros = new String[5][4];

        datosCompaneros[0][0] = "EMILIO";
        datosCompaneros[0][1] = "MARADIAGA";
        datosCompaneros[0][2] = "ROBOTICA";
        datosCompaneros[0][3] = "TEST";

        datosCompaneros[1][0] = "SOFIA";
        datosCompaneros[1][1] = "JiMENEZ";
        datosCompaneros[1][2] = "Computacion";
        datosCompaneros[1][3] = "IMSA";
        
        datosCompaneros[1][0] = "CINTIA";
        datosCompaneros[1][1] = "ALTAMIRANO";
        datosCompaneros[1][2] = "MAESTRIA";
        datosCompaneros[1][3] = "SPS";
        
        datosCompaneros[1][0] = "CARINA";
        datosCompaneros[1][1] = "REYES";
        datosCompaneros[1][2] = "ELECTRONICA";
        datosCompaneros[1][3] = "IMSA";

        datosCompaneros[1][0] = "ANDRES";
        datosCompaneros[1][1] = "CANALES";
        datosCompaneros[1][2] = "Computacion";
        datosCompaneros[1][3] = "SPS";

 // Imprimir los datos almacenados
        for (int i = 0; i < datosCompaneros.length; i++) {
            System.out.println("Nombre: " + datosCompaneros[i][0]);
            System.out.println("Apellido: " + datosCompaneros[i][1]);
            System.out.println("Carrera: " + datosCompaneros[i][2]);
            System.out.println("Lugar de Trabajo: " + datosCompaneros[i][3]);
            System.out.println();
        }
    }
}
